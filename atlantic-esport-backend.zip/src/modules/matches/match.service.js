const supabase = require('../../config/supabase');

const createMatch = async (player1, player2) => {
  const { data, error } = await supabase
    .from('matches')
    .insert([{ player1_id: player1, player2_id: player2 }])
    .select();

  if (error) throw new Error(error.message);
  return data;
};

module.exports = { createMatch };