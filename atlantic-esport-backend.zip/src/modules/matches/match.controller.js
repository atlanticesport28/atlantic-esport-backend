const service = require('./match.service');

const createMatch = async (req, res) => {
  try {
    const player1 = req.user.userId;
    const { player2 } = req.body;

    const match = await service.createMatch(player1, player2);
    res.json(match);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

module.exports = { createMatch };