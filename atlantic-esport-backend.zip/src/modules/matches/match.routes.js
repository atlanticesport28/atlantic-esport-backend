const express = require('express');
const router = express.Router();
const controller = require('./match.controller');
const authMiddleware = require('../../middleware/auth.middleware');

router.post('/create', authMiddleware, controller.createMatch);

module.exports = router;