const supabase = require('../../config/supabase');
const jwt = require('jsonwebtoken');

const register = async (email, password) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password
  });

  if (error) throw new Error(error.message);

  await supabase.from('users').insert([
    { id: data.user.id, email: data.user.email }
  ]);

  return data;
};

const login = async (email, password) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) throw new Error(error.message);

  const token = jwt.sign(
    { userId: data.user.id, email: data.user.email },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );

  return { user: data.user, token };
};

module.exports = { register, login };