const service = require('./leaderboard.service');

const getLeaderboard = async (req, res) => {
  try {
    const data = await service.getLeaderboard();
    res.json(data);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

module.exports = { getLeaderboard };