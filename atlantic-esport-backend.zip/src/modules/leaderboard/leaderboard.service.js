const supabase = require('../../config/supabase');

const getLeaderboard = async () => {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .order('elo', { ascending: false });

  if (error) throw new Error(error.message);
  return data;
};

module.exports = { getLeaderboard };